#include <stdlib.h>

int main(int argc, char *argv[])
{
  // TODO

  return EXIT_SUCCESS;
}